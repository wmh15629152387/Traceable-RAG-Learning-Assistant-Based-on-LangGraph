# Rerank already done in retrieve node for simplicity.
def node_rerank(state: dict) -> dict:
    return state
